﻿param([switch]$NoBrowser)
$ErrorActionPreference = 'Stop'
$port = 8765
$root = $PSScriptRoot
$listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, $port)
try { $listener.Start() } catch {
    Write-Host "Port $port is occupied. Close the other Carrier server and try again."
    exit 1
}
$url = "http://localhost:$port/carrier.html"
Write-Host "Carrier PC / 0.1.0-origin / build 61 / RU + EN"
Write-Host $url
Write-Host 'Keep this window open. Close it to stop the local server.'
if (-not $NoBrowser) { Start-Process $url }
$files = @{
    '/carrier.html' = @('carrier.html', 'text/html; charset=utf-8')
    '/' = @('carrier.html', 'text/html; charset=utf-8')
    '/carrier-locales.js' = @('carrier-locales.js', 'text/javascript; charset=utf-8')
    '/carrier-i18n.js' = @('carrier-i18n.js', 'text/javascript; charset=utf-8')
    '/carrier-persistence.js' = @('carrier-persistence.js', 'text/javascript; charset=utf-8')
    '/carrier-desktop.js' = @('carrier-desktop.js', 'text/javascript; charset=utf-8')
    '/carrier-experiments.js' = @('carrier-experiments.js', 'text/javascript; charset=utf-8')
    '/carrier-training.js' = @('carrier-training.js', 'text/javascript; charset=utf-8')
    '/weighted-half-time.mp3' = @('weighted-half-time.mp3', 'audio/mpeg')
}
try {
    while ($true) {
        $client = $listener.AcceptTcpClient()
        try {
            $client.ReceiveTimeout = 3000
            $client.SendTimeout = 5000
            $stream = $client.GetStream()
            $reader = [System.IO.StreamReader]::new($stream, [System.Text.Encoding]::ASCII, $false, 1024, $true)
            $request = $reader.ReadLine()
            if (-not $request) { continue }
            while ($reader.ReadLine()) {}
            $parts = $request.Split(' ')
            $route = $parts[1].Split('?')[0]
            if ($parts[0] -notin @('GET', 'HEAD')) {
                $status = '405 Method Not Allowed'; $type = 'text/plain'; $body = [byte[]]@()
            } elseif ($files.ContainsKey($route)) {
                $status = '200 OK'; $type = $files[$route][1]
                $body = [System.IO.File]::ReadAllBytes((Join-Path $root $files[$route][0]))
            } else {
                $status = '404 Not Found'; $type = 'text/plain'; $body = [byte[]]@()
            }
            $header = [System.Text.Encoding]::ASCII.GetBytes("HTTP/1.1 $status`r`nContent-Type: $type`r`nContent-Length: $($body.Length)`r`nCache-Control: no-store`r`nConnection: close`r`n`r`n")
            $stream.Write($header, 0, $header.Length)
            if ($parts[0] -ne 'HEAD') { $stream.Write($body, 0, $body.Length) }
            $stream.Flush()
        } catch { Write-Host ('Request: ' + $_.Exception.Message) }
        finally { $client.Dispose() }
    }
} finally { $listener.Stop() }
