﻿CARRIER PC / 0.1.0-origin / build 61 / RU + EN (US)

QUICK START — WINDOWS
1. Unzip the whole folder anywhere you like. Keep its files together.
2. Run START-Carrier.cmd. Keep the server window open.
3. Open http://localhost:8765/carrier.html in Chrome or Edge.
4. Pick RU or EN on the opening screen or in Settings. Your choice is saved.
5. Choose music for training. The built-in Weighted Half-Time track works offline.
6. Hit Play to lock the mouse. Esc frees it for menus.
No Python, Node.js, SDK, or extra install needed. The server listens only on loopback.

CONTROLS
W/S forward/back · A/D strafe · mouse look
LMB hold/release: charge/fire · E hold/release: charge/boost near Nodes
R Rebirth/Fusion · Q Higher Rebirth · C first-person view
RMB enter orbit/rest when available · F fullscreen · Esc free mouse
Physical keys work with the Russian keyboard layout too.

PROGRESS & AUDIO
Use the same browser, profile, and http://localhost:8765 address to keep your progress.
Progress and preferences stay on your computer. Incognito and clearing browser data can remove them.
Android and web saves do not transfer automatically.
Microphone and screen/tab audio require browser permission. Local audio files stay on your device.
If another Carrier server is already on port 8765, close it first. Avoid directly opening the HTML file;
START keeps a stable save address and allows the built-in track to load.

RU — БЫСТРЫЙ ЗАПУСК
Распакуй архив целиком и запусти START-Carrier.cmd. Оставь окно сервера открытым.
Открой http://localhost:8765/carrier.html в Chrome или Edge.
RU / EN доступны на первом экране и в настройках. Язык меняется без сброса прогресса.
Для сохранений используй прежний браузер, профиль и адрес localhost:8765.
Клавиши: WASD — движение, мышь — обзор, ЛКМ — выстрел/заряд, E — ускорение,
R — перерождение/слияние, Q — высшее перерождение, C — вид, F — полный экран, Esc — меню.

BUILD 61
Shared Android/PC localization: American English menus, training, skills, story messages,
Node library/editor, saves and HUD. Russian remains available. No physics or balance changes.
Includes the build60 fragment-registration fix. Save/settings schemas stay 1.
Work in progress. Real-device performance and audio capture still depend on your setup.